import React from "react";

export const Header = () => {
  return (
    <div className="header">
      <h1>Random Letters game</h1>
      <div>
        Type in the letters you want or auto generate and specify the total
        letters{" "}
      </div>
    </div>
  );
};
