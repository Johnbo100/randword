import React,{useState, useEffect} from "react";
import { Header } from "./componants/Header";
import "./App.css";
import Definition from "./componants/Definition";
import Letters from "./componants/Letters"


let alphabet = [...Array(26).keys()].map((i) => String.fromCharCode(i + 97));
console.log(alphabet);

function App() {
  const [numAuto, setNumAuto]=useState(5)
  const [word,setWord]=useState([])
  const [words,setWords]=useState([])
  let text;

  useEffect(() => {
    console.log('word changed')
  }, [word]);

  function permute(arr) {
    
    if (arr.length === 1) return arr
    
    let res = arr.map((d, i) => permute([...arr.slice(0, i),...arr.slice(i + 1)])
                                .map(v => [d,v].join(''))).flat()
    setWords(...words,res)
    return res
  }
  
  const clearList =()=>{
    setWords(words,[])
  }
 
 const handleClick = e => {
  e.preventDefault();
  clearList()
  let wordVal = word;
  console.log(permute(wordVal))
  
};

  const autogen = () =>{
    text=[]
    for (var i = 0; i < numAuto; i++)
      text.push(alphabet[Math.floor(Math.random()*alphabet.length)]);
      console.log('This is the text value' + text)
      setWord(text);
    
    console.log('here are the random letters' + word)
  }
  return (
    <div className="App">
      <Header />
      <Letters alpha={alphabet}/>
          <Definition />
      <div id="letterInput">
        <input type="text" placeholder="Type in your letters" id="Letters" value={word}/>
      </div>

      <div id="controlsWrapper">
        <input type="number" id="numLetters" value={numAuto} onChange={(e)=>setNumAuto(e.target.value)}/>
        <button onClick={autogen} id="numletbtn">Auto Generate</button>  
      </div>   

      <div>
          <button onClick={handleClick} id="poscombtn">Possible combinations</button>
      </div>
      <div className="words">
       
          {words.map(sword=>(
            <li>{sword}</li>
          ))}
        
      </div>
          
      
    </div>
  );
}

export default App;
